package Utils;

/**
 * Created by gostun on 10/7/2016.
 */
public class User {
    public String email;
    public String userId;
    public String token;
    public String secret;
}
